using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public Transform player; // Asigna aqu� el objeto del jugador desde el editor.
    public float speed = 5f; // Velocidad de persecuci�n del enemigo.
    private bool gameStarted = false; // Variable para saber si el juego ha comenzado.
    private int collisionCount = 0; // Contador de colisiones con el jugador.
    private Animator playerAnimator; // Referencia al Animator del jugador.
    private PlayerMovement playerMovementScript; // Referencia al script de movimiento del jugador.
    private float slowDownFactor = 0.5f; // Factor de desaceleraci�n.
    private float slowDownDuration = 2f; // Duraci�n de la desaceleraci�n.

    void Start()
    {
        if (player == null)
        {
            Debug.LogError("El jugador no est� asignado al script EnemyBehavior.");
        }

        playerAnimator = player.GetComponent<Animator>();
        if (playerAnimator == null)
        {
            Debug.LogError("El jugador no tiene un componente Animator.");
        }

        playerMovementScript = player.GetComponent<PlayerMovement>();
        if (playerMovementScript == null)
        {
            Debug.LogError("El jugador no tiene un script de movimiento.");
        }
    }

    void Update()
    {
        // Solo mover al enemigo cuando el juego haya comenzado
        if (gameStarted && player != null)
        {
            // Moverse hacia el jugador.
            Vector3 direction = (player.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;

            // Mirar hacia el jugador.
            transform.LookAt(player.position);
        }
    }

    // M�todo para activar el inicio del juego.
    public void StartGame()
    {
        gameStarted = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            collisionCount++;

            // En vez de matar al jugador, desacelerarlo cuando colisione
            if (collisionCount >= 1)  // Solo aplica desaceleraci�n al primer golpe
            {
                StartCoroutine(SlowDownPlayer());
                Debug.Log("Jugador ralentizado por el enemigo.");
            }
        }
    }

    // Coroutine para reducir la velocidad del jugador temporalmente
    private IEnumerator SlowDownPlayer()
    {
        if (playerMovementScript != null)
        {
            // Ralentizar el movimiento del jugador
            playerMovementScript.SetSpeed(playerMovementScript.GetSpeed() * slowDownFactor);

            // Esperar por un tiempo espec�fico
            yield return new WaitForSeconds(slowDownDuration);

            // Restaurar la velocidad normal del jugador
            playerMovementScript.SetSpeed(playerMovementScript.GetSpeed() / slowDownFactor);
        }
    }
}
